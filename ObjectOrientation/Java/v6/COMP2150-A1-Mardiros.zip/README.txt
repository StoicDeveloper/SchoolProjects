README file for Assignment 1 in COMP2150
Jan 31, 2020
Xian Mardiros
7862786

To compile, simply use 
javac Tutrfindr.java
javac -cp .:junit-platform-console-standalone-1.6.0.jar TestTutrfindr.java

to run the test, use
java -jar junit-platform-console-standalone-1.6.0.jar --class-path . --scan-class-path

to run, use 
java Tutrfindr

read text files using vim, its possible some difference in
indentation or other formating will exist due to 
difference in vim configuration.
