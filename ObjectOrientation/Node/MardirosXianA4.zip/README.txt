COMP2150 Assignment 4
Xian Mardiros, 7862786

execution instructions
----------------------

testing:
$ node tests.js

encoding:
$ node encode.js "filename.txt"
