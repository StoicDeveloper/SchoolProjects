// CLASS: OrderedItem
//
// Author: Xian Mardiros, 7862786
//
// REMARKS: unchanged
#include "OrderedItem.h"

OrderedItem::~OrderedItem() { }
