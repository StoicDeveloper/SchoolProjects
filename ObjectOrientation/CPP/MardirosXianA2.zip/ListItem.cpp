// CLASS: ListItem
//
// Author: Xian Mardiros, 7862786
//
// REMARKS: superclass for objects to be contained in
//          queues, unchanged from provided class
#include "ListItem.h"

ListItem::~ListItem() {}
