COMP-2150 Assignment 2
Feb 29, 3:30AM

Xian Mardiros, 7862786

To compile program, enter "make" command

to compile tests, uncomment lines 9-13 of makefile, and comment out lines 6-8
