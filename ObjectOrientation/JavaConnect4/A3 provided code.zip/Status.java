public enum Status {
    ONE, TWO, NEITHER
}
