public interface GameLogic {
    void setAnswer (int col);
}
