Instructions for Assignment 3
Author: Xian Mardiros, 7862786

Compilation Instructions 
$make

Run Instructions 
$java A3main
