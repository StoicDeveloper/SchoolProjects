// CLASS:   Status
//
// Author:  UM CS Department
//
// REMARKS: Unchanged from original
public enum Status {
    ONE, TWO, NEITHER
}
