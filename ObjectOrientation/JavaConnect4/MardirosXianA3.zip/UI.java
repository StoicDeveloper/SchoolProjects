// CLASS:   UI
//
// Author:  UM CS Department
//
// REMARKS: Unchanged from original
public interface UI {
    void lastMove(int lastCol);
    void gameOver(Status winner);
    void setInfo(Human h, int size);
}
