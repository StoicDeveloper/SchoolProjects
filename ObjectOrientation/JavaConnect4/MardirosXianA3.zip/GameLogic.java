// CLASS:   GameLogic
//
// Author:  UM CS Department
//
// REMARKS: Unchanged from original
public interface GameLogic {
    void setAnswer (int col);
}
