//--------------------------------
// NAME		        : Xian Mardiros
// STUDENT NUMBER	: 7862786
// COURSE		      : COMP 2150
// INSTRUCTOR	    : Mike Domaratski
// ASSIGNMENT	    : assignment 3    
// 
// REMARKS: This program runs a game of Connect
//          between a human player and an AI player
//
//-----------------------------------------
public class A3main{
    public static void main( String[] args ){
        Connect game = new Connect();
        game.run();
        System.out.println( "End of Processing" );
    }
}
