// CLASS:   Human
//
// Author:  UM CS Department
//
// REMARKS: Unchanged from original
public interface Human {
     void setAnswer(int col);
}
